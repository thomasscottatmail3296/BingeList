---
title: "The Dark Knight"
type: movie
franchise: "DC"
release_date: "2008-07-18"
status: "Not Watched"
spoiler_summary: true
---

# The Dark Knight

◇ INFORMATION
- Release date: 2008-07-18
- Franchise: [[DC]]

◇ WATCH STATUS
- [ ] Watched
- [ ] Rewatched
- [ ] Favourite

> [!spoiler]- SUMMARY — SPOILERS
> This episode follows the events of 16 - The Dark Knight, developing its central conflict and the Doctor's response.

> [!spoiler]- MAJOR SCENES — SPOILERS
> Timestamp data: unavailable / unverified.

◇ RELATIONSHIPS
- Universe: [[Universe Map]]

◇ SOURCES
- Metadata: DC official movie catalog / cross-check
- Summary reference: pending
- Timestamp reference: unavailable / unverified

◇ VIEWING PLATFORMS

[[07 - Data/Providers/Viewing Providers|◇ Open Australian Viewing Provider Directory]]

### Free
- Title availability: verify in provider directory / official site.

### Torrent — Legal and Non-Legal
- Legal: public-domain, rights-holder-authorised, or otherwise lawful distribution only.
- Non-Legal: status may be documented without piracy-site links or acquisition instructions.

### Paid
- Provider: verify
- Price (AUD): verify
- Billing occurrence: verify
