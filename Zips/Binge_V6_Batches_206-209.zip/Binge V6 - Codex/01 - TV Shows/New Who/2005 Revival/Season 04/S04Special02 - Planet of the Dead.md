---
title: "S04E02 — Planet of the Dead"
type: special
series: "New Who"
season: 4
episode: 2
air_date: "2009-04-11"
runtime: "60 min"
episode_type: "special"
status: "Not Watched"
universe: "Doctor Who / Whoniverse"
---

# S04E02 — Planet of the Dead

◇ INFORMATION

- Series: [[01 - TV Shows/New Who|New Who]]
- Season: [[01 - TV Shows/New Who/2005 Revival/Season 04|Season 04]]
- Episode: 2
- Air date: 2009-04-11
- Runtime: 60 min
- Type: special
- Universe: [[00 - Directory/Universes/Universe Map|Doctor Who / Whoniverse]]


◇ WATCH STATUS

- [ ] Watched
- [ ] Rewatched
- [ ] Favourite

> [!spoiler]- SUMMARY — SPOILERS
>
> This episode follows the events of S04Special02 - Planet of the Dead, developing its central conflict and the Doctor's response.

> [!spoiler]- MAJOR SCENES — SPOILERS
>
> Timestamp data: unavailable / unverified.

◇ RELATIONSHIPS

- Series: [[01 - TV Shows/New Who|New Who]]
- Season: [[01 - TV Shows/New Who/2005 Revival/Season 04|Season 04]]
- Universe: [[00 - Directory/Universes/Universe Map|Doctor Who / Whoniverse]]

◇ SOURCES

- Metadata: https://www.tvmaze.com/shows/210/doctor-who/episodeguide
- Cross-check: https://en.wikipedia.org/wiki/Doctor_Who_season_4
- Summary reference: pending dedicated paraphrase pass
- Timestamp reference: unavailable / unverified

◇ VIEWING PLATFORMS

[[07 - Data/Providers/Viewing Providers|◇ Open Australian Viewing Provider Directory]]

### Free
- Title availability: verify in provider directory / official site.

### Torrent — Legal and Non-Legal
- Legal: public-domain, rights-holder-authorised, or otherwise lawful distribution only.
- Non-Legal: status may be documented without piracy-site links or acquisition instructions.

### Paid
- Provider: verify
- Price (AUD): verify
- Billing occurrence: verify
