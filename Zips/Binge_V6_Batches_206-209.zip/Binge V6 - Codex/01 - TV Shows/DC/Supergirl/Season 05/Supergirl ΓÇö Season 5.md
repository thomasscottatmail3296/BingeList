---
title: "Supergirl — Season 5"
type: season
series: "Supergirl"
season: 5
status: "Not Watched"
spoiler_summary: true
---

# Supergirl — Season 5

◇ WATCH STATUS
- [ ] Watched
- [ ] Rewatched
- [ ] Favourite

> [!spoiler]- SUMMARY — SPOILERS
> Season summary: pending dedicated summary pass.

◇ RELATIONSHIPS
- Series: [[Supergirl]]
- Universe: [[Universe Map]]

◇ SOURCES
- Episode/season metadata: pending episode-level research

◇ VIEWING PLATFORMS

[[07 - Data/Providers/Viewing Providers|◇ Open Australian Viewing Provider Directory]]

### Free
- Title availability: verify in provider directory / official site.

### Torrent — Legal and Non-Legal
- Legal: public-domain, rights-holder-authorised, or otherwise lawful distribution only.
- Non-Legal: status may be documented without piracy-site links or acquisition instructions.

### Paid
- Provider: verify
- Price (AUD): verify
- Billing occurrence: verify
