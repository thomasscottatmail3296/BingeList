---
title: "The Simpsons — Season 2"
type: season
series: "The Simpsons"
season: 2
episode_count: 22
status: "Not Watched"
summary_status: "pending dedicated episode pass"
timestamp_status: "unavailable / unverified"
---

# The Simpsons — Season 2

◇ INFORMATION
- Series: [[The Simpsons]]
- Season: 2
- Episodes: 22
- Original run: Oct 11, 1990 → Jul 11, 1991

◇ WATCH STATUS
- [ ] Season watched
- [ ] Season rewatched
- [ ] Favourite season

◇ EPISODES
- Episode-level notes: 22 skeleton notes created in Batch 58; title/airdate metadata queued for verification.
- Metadata source: TVmaze / cross-check with published episode guides.

◇ NOTES
- This season architecture is an index layer only. No episode summaries or timestamps are fabricated here.

◇ VIEWING PLATFORMS

[[07 - Data/Providers/Viewing Providers|◇ Open Australian Viewing Provider Directory]]

### Free
- Title availability: verify in provider directory / official site.

### Torrent — Legal and Non-Legal
- Legal: public-domain, rights-holder-authorised, or otherwise lawful distribution only.
- Non-Legal: status may be documented without piracy-site links or acquisition instructions.

### Paid
- Provider: verify
- Price (AUD): verify
- Billing occurrence: verify
