---
title: "The Simpsons — Season 30"
type: season
series: "The Simpsons"
season: 30
episode_count: 23
status: "Not Watched"
summary_status: "pending dedicated episode pass"
timestamp_status: "unavailable / unverified"
---

# The Simpsons — Season 30

◇ INFORMATION
- Series: [[The Simpsons]]
- Season: 30
- Episodes: 23
- Original run: Sep 30, 2018 → May 12, 2019

◇ WATCH STATUS
- [ ] Season watched
- [ ] Season rewatched
- [ ] Favourite season

◇ EPISODES
- [[The Simpsons S30E01]] — Episode 1 — episode-level note pending
- [[The Simpsons S30E02]] — Episode 2 — episode-level note pending
- [[The Simpsons S30E03]] — Episode 3 — episode-level note pending
- [[The Simpsons S30E04]] — Episode 4 — episode-level note pending
- [[The Simpsons S30E05]] — Episode 5 — episode-level note pending
- [[The Simpsons S30E06]] — Episode 6 — episode-level note pending
- [[The Simpsons S30E07]] — Episode 7 — episode-level note pending
- [[The Simpsons S30E08]] — Episode 8 — episode-level note pending
- [[The Simpsons S30E09]] — Episode 9 — episode-level note pending
- [[The Simpsons S30E10]] — Episode 10 — episode-level note pending
- [[The Simpsons S30E11]] — Episode 11 — episode-level note pending
- [[The Simpsons S30E12]] — Episode 12 — episode-level note pending
- [[The Simpsons S30E13]] — Episode 13 — episode-level note pending
- [[The Simpsons S30E14]] — Episode 14 — episode-level note pending
- [[The Simpsons S30E15]] — Episode 15 — episode-level note pending
- [[The Simpsons S30E16]] — Episode 16 — episode-level note pending
- [[The Simpsons S30E17]] — Episode 17 — episode-level note pending
- [[The Simpsons S30E18]] — Episode 18 — episode-level note pending
- [[The Simpsons S30E19]] — Episode 19 — episode-level note pending
- [[The Simpsons S30E20]] — Episode 20 — episode-level note pending
- [[The Simpsons S30E21]] — Episode 21 — episode-level note pending
- [[The Simpsons S30E22]] — Episode 22 — episode-level note pending
- [[The Simpsons S30E23]] — Episode 23 — episode-level note pending

◇ NOTES
- This season architecture is an index layer only. No episode summaries or timestamps are fabricated here.
- Episode titles, metadata, summaries, and scene data will be added in later dedicated passes.

◇ VIEWING PLATFORMS

[[07 - Data/Providers/Viewing Providers|◇ Open Australian Viewing Provider Directory]]

### Free
- Title availability: verify in provider directory / official site.

### Torrent — Legal and Non-Legal
- Legal: public-domain, rights-holder-authorised, or otherwise lawful distribution only.
- Non-Legal: status may be documented without piracy-site links or acquisition instructions.

### Paid
- Provider: verify
- Price (AUD): verify
- Billing occurrence: verify
